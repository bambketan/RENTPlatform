
var mongoose= require('mongoose')
//var connec=config.get('mongouri');
const constr=require('./default.json');
const app=require('express')

//console.log(constr.mongouri)

const connectdb= async() =>{
try{
    await mongoose.connect(constr.mongouri,{ useNewUrlParser: true,useUnifiedTopology: true })
    console.log('MONGOO');
}
catch(err){
    console.log(err.message)
    process.exit(1);
}

}

module.exports=connectdb;
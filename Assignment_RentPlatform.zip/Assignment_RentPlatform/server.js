const path=require('path')
const express=require('express')
const cors=require('cors')
const dotenv=require('dotenv')
const connectdb =require('./config/db')
// to load env variables
dotenv.config({path:'./config/config.env'})
const app=express();

//body parser
// app.use(express.json)
// app.use(cors())

connectdb()

app.use('/api/store',require('./routes/item'))

app.use('/api/addStore',require('./routes/item'))


//app.use(express.static(path.join(__dirname,'public')))
app.use(express.static('index'))

const PORT=process.env.PORT || 3000
app.listen(PORT,()=>
console.log(`RUNNING ON PORT ${PORT}`)
)
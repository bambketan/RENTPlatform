const mongoose=require('mongoose')

const ITEM_Schema=new mongoose.Schema({
    user:[
        {type: Schema.Types.ObjectId, ref: 'User_Schema'}
      ],
    ItemName:
    {
        type:String,
        required:[true,'Please add a Item'],
        unique:true,
        trim:true,
        maxlength:[10,'Max length 10']

    },
    ItemRentprice:{
        type:Number,
        required:[true,'Please add item price']
    }, 
    Actualprice:{
      type:Number,
      required:[true,'Please add actual price']
  },    
    Manufacturing_Date:{
        type:Date       
    },
    item_type:{
        type:String,
        required:[true,'Please mention Own/rent']
    }
});


module.exports = mongoose.model('ITEM_Schema', ITEM_Schema)
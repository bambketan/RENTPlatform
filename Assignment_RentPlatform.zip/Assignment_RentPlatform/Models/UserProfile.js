const mongoose=require('mongoose')

const User_Schema=new mongoose.Schema({
    UserName:
    {
        type:String,
        required:[true,'Please add a store iD'],
       // unique:true,
        trim:true,
        maxlength:[10,'Max length 10']

    },
    ContactNo:{
        type:Number,
        required:[true,'Please add contact no']
    }
});


module.exports = mongoose.model('User_Schema', ITEM_Schema)
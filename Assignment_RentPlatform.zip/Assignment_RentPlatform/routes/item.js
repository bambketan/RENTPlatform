const express =require('express')
const router=express.Router();
const ITEM=require('../Models/ITEM');
const { request } = require('express');


router.get('/',async(req,res)=>{
    try{
        const store=await ITEM.find();
        return res.status(200).json({
            success:true,
            data:store,
            count:store.length
        })
    }
    catch(err){
        res.send(400).json({
            error:'Server error'
        })

    }
    // console.log("ALL OK")
    // res.send("HELLO")
})



router.post('/',async(req,res)=>{
    try{
        console.log(req)
        console.log("AD STORE")
      
            let msg = new ITEM({
                ItemName:'Book1',
                ItemRentprice:100,
                Actualprice:300

              })
              
              msg.save()
                 .then(doc => {res.status(200).send(doc)
                   console.log(doc)
                 })
                 .catch(err => {res.status(404).send(err.message)
                   console.error(err)
                 })
        
    }
    catch(err){
        res.send(400).json({
            error:'Server error'
        })

    }
    // console.log("ALL OK")
    // res.send("HELLO")
})



//router.route('/').get(getStores)
module.exports=router;